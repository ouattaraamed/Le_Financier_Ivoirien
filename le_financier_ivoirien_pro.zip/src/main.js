import { createClient } from '@supabase/supabase-js'
import './style.css'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || ''
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || ''
const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? createClient(SUPABASE_URL,SUPABASE_ANON_KEY) : null

const demo = [
 {id:1,title:"BRVM : les marchés financiers africains accélèrent leur transformation",category:"BRVM & Marchés",excerpt:"Analyses, tendances et informations pour comprendre les marchés financiers en Afrique de l’Ouest.",published_at:"2026-09-10",featured:true},
 {id:2,title:"Les perspectives de l’économie ivoirienne à suivre",category:"Économie",excerpt:"Les principaux moteurs de croissance et les indicateurs à surveiller.",published_at:"2026-09-09"},
 {id:3,title:"Le secteur bancaire poursuit sa transformation digitale",category:"Banques & Finance",excerpt:"Les nouvelles stratégies des acteurs financiers régionaux.",published_at:"2026-09-09"},
 {id:4,title:"5 réflexes pour mieux investir en bourse",category:"Investissement",excerpt:"Un guide pédagogique pour les nouveaux investisseurs.",published_at:"2026-09-08"}
]

async function getArticles(){
 if(!supabase) return demo
 const {data,error}=await supabase.from('articles').select('*').eq('status','published').order('published_at',{ascending:false})
 if(error) return demo
 return data?.length ? data : demo
}

function esc(s=''){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function render(articles){
 const featured=articles.find(a=>a.featured)||articles[0]
 const rest=articles.filter(a=>a.id!==featured?.id)
 document.querySelector('#app').innerHTML=`
 <div class="top">Le média financier de référence en Côte d’Ivoire <span>À propos · Contact · Newsletter</span></div>
 <header><a class="brand" href="#"><b>↗</b><div><h1>Le Financier Ivoirien</h1><i>L’information financière qui compte.</i></div></a><a class="admin" href="#admin">Administration</a></header>
 <nav>${['Accueil','BRVM & Marchés','Banques & Finance','Entreprises','Économie','Afrique','Investissement','Interviews'].map(x=>`<a>${x}</a>`).join('')}</nav>
 <div class="ticker"><strong>⚡ FLASH INFO</strong><span>Actualité, analyses et décryptages des marchés ouest-africains.</span></div>
 <main>
  <section class="hero"><div><label>${esc(featured?.category||'À LA UNE')}</label><h2>${esc(featured?.title||'Le Financier Ivoirien')}</h2><p>${esc(featured?.excerpt||'Votre source d’information économique et financière.')}</p><small>10 septembre 2026 · 4 min de lecture</small></div></section>
  <section class="markets"><h3>📊 INDICES & MARCHÉS</h3><div class="mgrid"><div>BRVM Composite <b>—</b><em>Données à connecter</em></div><div>BRVM 30 <b>—</b><em>Données à connecter</em></div><div>Obligations <b>—</b><em>Suivi du marché</em></div><div>EUR / XOF <b>655,96</b><em>Stable</em></div><div>USD / XOF <b>—</b><em>Cours indicatif</em></div></div></section>
  <section class="news"><div class="section"><h3>Dernières actualités</h3><div class="cards">${rest.map(a=>`<article><div class="photo"></div><small>${esc(a.category||'ACTUALITÉ')}</small><h2>${esc(a.title)}</h2><p>${esc(a.excerpt||'')}</p><time>${esc(a.published_at||'')}</time></article>`).join('')}</div></div>
  <aside><h3>Newsletter</h3><p>Recevez l’essentiel de l’actualité financière.</p><form id="newsletter"><input type="email" placeholder="Votre e-mail" required><button>S’inscrire</button></form><hr><h3>Rubriques</h3><p>BRVM · Banques · Entreprises · Économie · Investissement · Afrique</p></aside></section>
 </main><footer><b>Le Financier Ivoirien</b><span>© 2026 — Tous droits réservés.</span></footer>`
 document.querySelector('#newsletter').onsubmit=async(e)=>{e.preventDefault();const email=e.target[0].value;if(supabase){await supabase.from('newsletter_subscribers').insert({email})};alert('Merci, votre inscription est enregistrée.')}
}
getArticles().then(render)

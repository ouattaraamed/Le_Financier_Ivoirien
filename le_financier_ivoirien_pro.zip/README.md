# Le Financier Ivoirien — version pro

## Lancer en local
1. Installer Node.js 20+.
2. `npm install`
3. Copier `.env.example` vers `.env` et renseigner les clés Supabase.
4. `npm run dev`

## Déploiement
Le projet est compatible avec Vercel, Netlify ou Cloudflare Pages.
Commande de build : `npm run build`
Répertoire de sortie : `dist`

## Base de données
Importer `supabase.sql` dans Supabase SQL Editor.

## Important
Cette livraison contient le site public et la structure de données prête pour un vrai CMS.
L'administration sécurisée doit utiliser Supabase Auth (compte éditeur/admin) et des politiques RLS strictes. Les données BRVM doivent être reliées à une source autorisée avant affichage en temps réel.
